#!/usr/bin/env python

import networkx as nx
import matplotlib.pyplot as plt
from copy import deepcopy
import time
from helpers import draw_graph, name_products, test_molecule_isomorphism, display_molecules, molecule_to_drawgraph, carbon_lst, print_path
from reactions import hydrobromination, hydration, dehydration
from classes import atom, molecule, molecule_path_node
from methods import brute_force


reaction_dict = {"hydrobromination": hydrobromination, "hydration": hydration, "dehydration": dehydration}
carbons = carbon_lst(10)
oxygen1 = atom("oxygen", "oxygen1")
hydrogen1 = atom("hydrogen", "hydrogen1")

start = molecule()
start.add_atoms(carbons[0:5] + [oxygen1, hydrogen1])
start.add_bonds([(carbons[0], carbons[1], 1), (carbons[1], carbons[2], 2),(carbons[2], carbons[3], 1), (carbons[3], carbons[4], 2)])
start.add_bonds([(carbons[3], oxygen1, 1), (oxygen1, hydrogen1, 1)])

#molecule_to_drawgraph(start, "starting molecule")

goal = molecule()

bromine1 = atom("bromine", "bromine1")
bromine2 = atom("bromine", "bromine2")
bromine3 = atom("bromine", "bromine3")
goal.add_atoms(carbons[5:10] + [bromine1, bromine2, bromine3])
goal.add_bonds([(carbons[5], carbons[6], 1), (carbons[6], carbons[7], 1), (carbons[7], carbons[8], 1), (carbons[8], carbons[9], 1)])
goal.add_bonds([(carbons[6], bromine1, 1), (carbons[7], bromine2, 1), (carbons[8], bromine3, 1)])

#molecule_to_drawgraph(goal, "goal molecule")

beg = time.time()
print_list = brute_force(start, goal, 3, reaction_dict)
end = time.time()
for i in print_list: 
    molecule_to_drawgraph(i[0], i[1])
print("took " + str(end-beg) + " seconds")